import React, { useState } from 'react';
import { Button } from './Button';
import { UserProfile } from '../types';
import { authService } from '../services/mockDatabase';
import { Flame, User, ArrowRight } from 'lucide-react';

interface AuthScreenProps {
  onLoginSuccess: (user: UserProfile) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLoginSuccess }) => {
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    setLoading(true);
    try {
      const user = await authService.login(name);
      onLoginSuccess(user);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md space-y-8 relative z-10">
        <div className="text-center space-y-2">
           <div className="inline-flex bg-zinc-900 p-4 rounded-2xl mb-4 border border-zinc-800 shadow-xl">
              <Flame className="text-primary w-10 h-10" fill="currentColor" fillOpacity={0.2} />
           </div>
           <h1 className="text-4xl font-black text-white tracking-tight">Metcon<span className="text-primary">Master</span></h1>
           <p className="text-zinc-400 text-lg">Your intelligent workout companion.</p>
        </div>
        
        <div className="bg-card border border-zinc-800 rounded-2xl p-8 shadow-2xl">
          <form onSubmit={handleStart} className="space-y-6">
             <div className="space-y-2">
               <h2 className="text-xl font-bold text-white">Create Your Profile</h2>
               <p className="text-sm text-zinc-500">Enter your name to start tracking your benchmarks.</p>
             </div>
             
             <div className="space-y-2">
               <label className="text-xs font-semibold text-zinc-500 uppercase tracking-widest">Athlete Name</label>
               <div className="relative">
                 <User className="absolute left-3 top-3 text-zinc-500" size={18} />
                 <input 
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Rich Froning"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                    required
                 />
               </div>
             </div>

             <Button type="submit" className="w-full shadow-lg shadow-primary/20" size="lg" isLoading={loading}>
                Get Started <ArrowRight size={18} className="ml-2" />
             </Button>
          </form>
        </div>
        <p className="text-center text-xs text-zinc-600">Local data storage. No cloud account required.</p>
      </div>
    </div>
  );
};