import React, { useState, useEffect, useRef } from 'react';
import { Workout } from '../types';
import { Button } from './Button';
import { StarRating } from './StarRating';
import { X, Play, Pause, Square, ChevronDown, ChevronUp, RefreshCw, Bookmark, BookmarkCheck, Clock, Timer as TimerIcon, ArrowLeft } from 'lucide-react';

interface ActiveWorkoutOverlayProps {
  workout: Workout;
  onClose: () => void;
  onComplete: (rating: number | undefined, shouldSave: boolean) => void;
  isSavedInitial: boolean;
}

type TimerMode = 'FOR_TIME' | 'AMRAP' | 'EMOM';

const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

export const ActiveWorkoutOverlay: React.FC<ActiveWorkoutOverlayProps> = ({ 
  workout, 
  onClose, 
  onComplete,
  isSavedInitial 
}) => {
  const [viewState, setViewState] = useState<'SETUP' | 'RUNNING' | 'SUMMARY'>('SETUP');
  const [timerMode, setTimerMode] = useState<TimerMode>('FOR_TIME');
  const [initialTime, setInitialTime] = useState(0); // In seconds (for AMRAP)
  const [timeLeft, setTimeLeft] = useState(0);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [emomRound, setEmomRound] = useState(1);
  
  // Summary State
  const [rating, setRating] = useState<number | undefined>(workout.userRating);
  const [isSaved, setIsSaved] = useState(isSavedInitial);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const descriptionLines = workout.description.split('\n').filter(line => line.trim().length > 0);

  // Auto-detect timer settings on mount
  useEffect(() => {
    const typeUpper = workout.type.toUpperCase();
    if (typeUpper.includes('AMRAP')) {
      setTimerMode('AMRAP');
      // Try to extract minutes
      const match = typeUpper.match(/AMRAP\s?(\d+)/);
      if (match && match[1]) {
        const mins = parseInt(match[1]);
        setInitialTime(mins * 60);
        setTimeLeft(mins * 60);
      } else {
        setInitialTime(600); // Default 10 mins
        setTimeLeft(600);
      }
    } else if (typeUpper.includes('EMOM')) {
      setTimerMode('EMOM');
      setInitialTime(60); // 1 minute intervals
      setTimeLeft(60);
    } else {
      setTimerMode('FOR_TIME');
    }
    // Skip setup if we want immediate start, but Setup is safer
    setViewState('SETUP');
  }, [workout]);

  // Timer Logic
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setElapsedTime(prev => prev + 1);
        
        if (timerMode === 'AMRAP') {
          setTimeLeft(prev => {
            if (prev <= 1) {
              setIsRunning(false);
              setViewState('SUMMARY');
              return 0;
            }
            return prev - 1;
          });
        } else if (timerMode === 'EMOM') {
           setTimeLeft(prev => {
             if (prev <= 1) {
               setEmomRound(r => r + 1);
               return 60; // Reset for next minute
             }
             return prev - 1;
           });
        }
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, timerMode]);

  const handleStart = () => {
    setViewState('RUNNING');
    setIsRunning(true);
  };

  const handleFinish = () => {
    setIsRunning(false);
    setViewState('SUMMARY');
  };

  const handleModeChange = (mode: TimerMode) => {
    setTimerMode(mode);
    setIsRunning(false);
    setElapsedTime(0);
    setEmomRound(1);
    
    if (mode === 'AMRAP') {
      const defaultTime = 12 * 60;
      setInitialTime(defaultTime);
      setTimeLeft(defaultTime);
    } else if (mode === 'EMOM') {
      setInitialTime(60);
      setTimeLeft(60);
    } else {
      setInitialTime(0);
      setTimeLeft(0);
    }
  };

  const adjustTime = (seconds: number) => {
    setInitialTime(prev => {
      const newVal = Math.max(60, prev + seconds);
      setTimeLeft(newVal);
      return newVal;
    });
  };

  if (viewState === 'SUMMARY') {
    return (
      <div className="fixed inset-0 z-50 bg-dark flex flex-col animate-in fade-in duration-300">
        <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-8 text-center">
          <div className="space-y-2">
             <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrophyIcon className="text-primary" size={32} />
             </div>
             <h2 className="text-3xl font-bold text-white">Workout Complete!</h2>
             <p className="text-zinc-400">Great work crushing {workout.name}.</p>
          </div>

          <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800 w-full max-w-sm">
             <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                   <p className="text-xs text-zinc-500 uppercase font-semibold">Total Time</p>
                   <p className="text-2xl font-mono text-white font-bold">{formatTime(elapsedTime)}</p>
                </div>
                {timerMode === 'EMOM' && (
                  <div>
                    <p className="text-xs text-zinc-500 uppercase font-semibold">Rounds</p>
                    <p className="text-2xl font-mono text-white font-bold">{emomRound}</p>
                  </div>
                )}
             </div>
          </div>

          <div className="space-y-4 w-full max-w-sm">
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-300">Rate this workout</label>
              <div className="flex justify-center p-4 bg-zinc-900/50 rounded-xl border border-zinc-800">
                <StarRating rating={rating || 0} onRate={setRating} size={32} />
              </div>
            </div>

            <button 
              onClick={() => setIsSaved(!isSaved)}
              className={`w-full flex items-center justify-center gap-2 p-4 rounded-xl border transition-all duration-200 ${isSaved ? 'bg-primary/10 border-primary text-primary' : 'bg-transparent border-zinc-700 text-zinc-400 hover:text-white'}`}
            >
              {isSaved ? <BookmarkCheck size={20} /> : <Bookmark size={20} />}
              {isSaved ? 'Saved to Library' : 'Add to Saved Workouts'}
            </button>
          </div>
        </div>
        
        <div className="p-6 border-t border-zinc-800 bg-zinc-900/80 backdrop-blur-md">
          <Button size="lg" className="w-full" onClick={() => onComplete(rating, isSaved)}>
            Done & Return Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-dark flex flex-col h-[100dvh]">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-md z-10">
        <button onClick={onClose} className="text-zinc-400 hover:text-white flex items-center gap-1">
          <ArrowLeft size={24} />
          <span className="text-sm font-medium ml-1">Back</span>
        </button>
        <h3 className="font-semibold text-white truncate max-w-[200px] absolute left-1/2 -translate-x-1/2">{workout.name}</h3>
        <div className="w-10"></div> {/* Spacer to balance the header if needed, or remove */}
      </div>

      {/* Main Scrollable Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="flex flex-col items-center pt-8 pb-32 px-4">
          
          {/* Timer Display */}
          <div className="mb-8 w-full max-w-sm">
             {viewState === 'SETUP' ? (
                <div className="bg-zinc-900 rounded-2xl p-6 border border-zinc-800 shadow-xl">
                   <div className="flex justify-between items-center mb-6 bg-black/40 p-1 rounded-lg">
                      {(['FOR_TIME', 'AMRAP', 'EMOM'] as TimerMode[]).map(m => (
                        <button
                          key={m}
                          onClick={() => handleModeChange(m)}
                          className={`flex-1 text-xs font-bold py-2 rounded-md transition-colors ${timerMode === m ? 'bg-zinc-700 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                        >
                          {m.replace('_', ' ')}
                        </button>
                      ))}
                   </div>

                   <div className="text-center mb-6">
                      <div className="text-6xl font-black font-mono text-white tracking-wider tabular-nums">
                         {timerMode === 'FOR_TIME' ? formatTime(0) : formatTime(timeLeft)}
                      </div>
                      <p className="text-zinc-500 text-sm mt-2 font-medium">
                        {timerMode === 'FOR_TIME' ? 'STOPWATCH' : timerMode === 'AMRAP' ? 'TIME CAP' : 'INTERVAL (1 MIN)'}
                      </p>
                   </div>

                   {(timerMode === 'AMRAP') && (
                     <div className="flex justify-center gap-4">
                        <button onClick={() => adjustTime(-60)} className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-300 hover:bg-zinc-700"><ChevronDown size={20}/></button>
                        <button onClick={() => adjustTime(60)} className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-300 hover:bg-zinc-700"><ChevronUp size={20}/></button>
                     </div>
                   )}
                </div>
             ) : (
                <div className="text-center mb-8 relative">
                   <div className={`text-7xl sm:text-8xl font-black font-mono tracking-tight tabular-nums ${isRunning ? 'text-white' : 'text-zinc-500'}`}>
                      {timerMode === 'FOR_TIME' ? formatTime(elapsedTime) : formatTime(timeLeft)}
                   </div>
                   <p className="text-primary font-bold tracking-widest uppercase text-sm mt-2 animate-pulse">
                     {isRunning ? 'Workout in Progress' : 'Paused'}
                   </p>
                   {timerMode === 'EMOM' && (
                     <div className="absolute top-0 right-0 bg-zinc-800 px-3 py-1 rounded-full text-xs font-bold text-zinc-300 border border-zinc-700">
                        Round {emomRound}
                     </div>
                   )}
                </div>
             )}
          </div>

          {/* Workout Details */}
          <div className="w-full max-w-md space-y-6">
             <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800">
                <div className="text-lg text-zinc-200 leading-relaxed font-medium">
                  {descriptionLines.map((line, index) => (
                    <div key={index} className="mb-3 last:mb-0 border-l-2 border-zinc-700 pl-3">
                      {line}
                    </div>
                  ))}
                </div>
             </div>
             
             {workout.tips && (
               <div className="bg-blue-500/10 p-4 rounded-xl border border-blue-500/20">
                  <p className="text-blue-300 text-sm italic">
                    <span className="font-bold not-italic mr-2">Tip:</span> 
                    {workout.tips}
                  </p>
               </div>
             )}
          </div>
        </div>
      </div>

      {/* Sticky Controls Footer */}
      <div className="p-4 bg-zinc-900/90 backdrop-blur-xl border-t border-zinc-800 safe-area-bottom">
        <div className="max-w-md mx-auto flex gap-3">
           {viewState === 'SETUP' ? (
             <Button size="lg" className="w-full text-lg h-14" onClick={handleStart}>
                <Play className="mr-2 fill-current" /> Start Workout
             </Button>
           ) : (
             <>
                <button 
                  onClick={() => setIsRunning(!isRunning)}
                  className={`flex-1 flex items-center justify-center rounded-xl font-bold text-lg h-14 transition-colors ${isRunning ? 'bg-zinc-800 text-zinc-200' : 'bg-green-600 text-white'}`}
                >
                   {isRunning ? <><Pause className="mr-2 fill-current" /> Pause</> : <><Play className="mr-2 fill-current" /> Resume</>}
                </button>
                <button 
                  onClick={handleFinish}
                  className="flex-1 flex items-center justify-center rounded-xl font-bold text-lg h-14 bg-red-500/10 text-red-500 border border-red-500/50 hover:bg-red-500/20"
                >
                   <Square className="mr-2 fill-current" size={18} /> Finish
                </button>
             </>
           )}
        </div>
      </div>
    </div>
  );
};

// Simple Icon component for the summary screen
function TrophyIcon({ size, className }: { size: number, className: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
      <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
      <path d="M4 22h16" />
      <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22" />
      <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22" />
      <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z" />
    </svg>
  );
}