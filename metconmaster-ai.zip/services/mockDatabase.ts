import { UserProfile, Workout, CompletedWorkout } from "../types";

// Keys for local storage
const STORAGE_KEYS = {
  USER: 'metcon_user_profile',
  SAVED_WORKOUTS: 'metcon_saved_workouts',
  HISTORY: 'metcon_workout_history'
};

export const authService = {
  isConfigured: () => true,

  // Simplified: No OTP needed, just local persistence
  login: async (name: string): Promise<UserProfile> => {
    const newUser: UserProfile = {
      id: crypto.randomUUID(),
      name: name || 'Athlete',
      email: '',
      phone: '',
      joinDate: new Date().toISOString(),
      workoutsCompleted: 0
    };
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(newUser));
    return newUser;
  },

  logout: async () => {
    localStorage.removeItem(STORAGE_KEYS.USER);
    // We optionally keep workouts/history or clear them. 
    // Usually, logout in a local-only app might mean "Reset App"
    localStorage.removeItem(STORAGE_KEYS.SAVED_WORKOUTS);
    localStorage.removeItem(STORAGE_KEYS.HISTORY);
  },

  subscribeToAuth: (callback: (user: UserProfile | null) => void) => {
    const stored = localStorage.getItem(STORAGE_KEYS.USER);
    if (stored) {
      try {
        callback(JSON.parse(stored));
      } catch {
        callback(null);
      }
    } else {
      callback(null);
    }
    // Return dummy unsubscribe
    return () => {};
  },

  updateProfile: async (updates: Partial<UserProfile>): Promise<UserProfile> => {
    const stored = localStorage.getItem(STORAGE_KEYS.USER);
    if (!stored) throw new Error("No user profile found");
    const user = JSON.parse(stored);
    const updated = { ...user, ...updates };
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updated));
    return updated;
  }
};

export const dbService = {
  getSavedWorkouts: async (userId: string): Promise<Workout[]> => {
    const stored = localStorage.getItem(STORAGE_KEYS.SAVED_WORKOUTS);
    return stored ? JSON.parse(stored) : [];
  },

  saveWorkout: async (userId: string, workout: Workout): Promise<void> => {
    const current = await dbService.getSavedWorkouts(userId);
    if (!current.some(w => w.id === workout.id)) {
      const updated = [...current, workout];
      localStorage.setItem(STORAGE_KEYS.SAVED_WORKOUTS, JSON.stringify(updated));
    }
  },

  removeWorkout: async (userId: string, workoutId: string): Promise<void> => {
    const current = await dbService.getSavedWorkouts(userId);
    const updated = current.filter(w => w.id !== workoutId);
    localStorage.setItem(STORAGE_KEYS.SAVED_WORKOUTS, JSON.stringify(updated));
  },

  recordCompletedWorkout: async (userId: string, workout: Workout, rating?: number): Promise<void> => {
    const history = await dbService.getWorkoutHistory(userId);
    const newEntry: CompletedWorkout = {
      historyId: crypto.randomUUID(),
      workout,
      completedAt: new Date().toISOString(),
      rating
    };
    const updatedHistory = [newEntry, ...history];
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(updatedHistory));
    
    // Increment count in profile
    const profileStored = localStorage.getItem(STORAGE_KEYS.USER);
    if (profileStored) {
      const profile = JSON.parse(profileStored);
      profile.workoutsCompleted = (profile.workoutsCompleted || 0) + 1;
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(profile));
    }
  },

  getWorkoutHistory: async (userId: string): Promise<CompletedWorkout[]> => {
    const stored = localStorage.getItem(STORAGE_KEYS.HISTORY);
    return stored ? JSON.parse(stored) : [];
  }
};