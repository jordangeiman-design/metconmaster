import React from 'react';

interface FilterChipProps {
  label: string;
  isSelected: boolean;
  onClick: () => void;
}

export const FilterChip: React.FC<FilterChipProps> = ({ label, isSelected, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`
        px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 border
        ${isSelected 
          ? 'bg-primary/20 border-primary text-primary' 
          : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:border-zinc-500 hover:text-zinc-200'}
      `}
    >
      {label}
    </button>
  );
};