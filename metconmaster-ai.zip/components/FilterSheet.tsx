import React from 'react';
import { FilterState, Equipment, Focus, TimeDomain, Difficulty, RunningSpace, BodyPartEmphasis, WorkoutStructure } from '../types';
import { EQUIPMENT_OPTIONS, TIME_OPTIONS, DIFFICULTY_OPTIONS, FOCUS_OPTIONS, RUNNING_OPTIONS, BODY_PART_OPTIONS, STRUCTURE_OPTIONS } from '../constants';
import { FilterChip } from './FilterChip';
import { X, SlidersHorizontal, MapPin, Star, Target, Layout } from 'lucide-react';
import { Button } from './Button';

interface FilterSheetProps {
  isOpen: boolean;
  onClose: () => void;
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  onApply: () => void;
}

const WEIGHT_OPTIONS = ['Light', 'Medium', 'Heavy'];

export const FilterSheet: React.FC<FilterSheetProps> = ({ isOpen, onClose, filters, setFilters, onApply }) => {
  if (!isOpen) return null;

  const toggleEquipment = (item: Equipment) => {
    setFilters(prev => ({
      ...prev,
      equipment: prev.equipment.includes(item) 
        ? prev.equipment.filter(i => i !== item)
        : [...prev.equipment, item]
    }));
  };

  const toggleFocus = (item: Focus) => {
    setFilters(prev => ({
      ...prev,
      focus: prev.focus.includes(item)
        ? prev.focus.filter(i => i !== item)
        : [...prev.focus, item]
    }));
  };

  const toggleBodyPart = (item: BodyPartEmphasis) => {
    setFilters(prev => ({
      ...prev,
      bodyParts: prev.bodyParts.includes(item)
        ? prev.bodyParts.filter(i => i !== item)
        : [...prev.bodyParts, item]
    }));
  };

  const updateWeight = (type: 'dumbbells' | 'kettlebell' | 'barbell', value: string) => {
    setFilters(prev => ({
      ...prev,
      equipmentWeights: {
        ...prev.equipmentWeights,
        [type]: prev.equipmentWeights[type] === value ? '' : value
      }
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-card w-full max-w-lg max-h-[90vh] sm:rounded-2xl rounded-t-2xl flex flex-col shadow-2xl border border-zinc-800">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-zinc-800">
          <div className="flex items-center gap-2 text-white font-semibold">
            <SlidersHorizontal size={20} className="text-primary" />
            <span>Customize Workout</span>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-8">
          
          <section>
            <h4 className="text-sm font-semibold text-zinc-300 mb-3 uppercase tracking-wider flex items-center gap-2">
              <Star size={14} className="text-yellow-500" /> Quality Control
            </h4>
            <div className="flex flex-wrap gap-2">
               <button
                  onClick={() => setFilters(prev => ({ ...prev, minRating: prev.minRating === 4 ? 0 : 4 }))}
                  className={`
                    px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 border flex items-center gap-2
                    ${filters.minRating === 4 
                      ? 'bg-yellow-500/10 border-yellow-500/50 text-yellow-500' 
                      : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:border-zinc-500 hover:text-zinc-200'}
                  `}
                >
                  <Star size={16} fill={filters.minRating === 4 ? "currentColor" : "none"} />
                  4+ Stars Only (Community Faves)
                </button>
            </div>
          </section>

          <section>
            <h4 className="text-sm font-semibold text-zinc-300 mb-3 uppercase tracking-wider flex items-center gap-2">
              <Layout size={14} className="text-secondary" /> Workout Structure
            </h4>
            <div className="flex flex-wrap gap-2">
              {STRUCTURE_OPTIONS.map(opt => (
                <FilterChip 
                  key={opt} 
                  label={opt} 
                  isSelected={filters.structure === opt} 
                  onClick={() => setFilters(prev => ({ ...prev, structure: opt }))} 
                />
              ))}
            </div>
            {filters.structure === 'EMOM (Varied)' && (
              <p className="mt-2 text-[10px] text-zinc-500 italic">Includes E2MOM, E3MOM, and alternating minute formats.</p>
            )}
            {filters.structure === 'Intervals / Work-Rest' && (
              <p className="mt-2 text-[10px] text-zinc-500 italic">Focused on work-to-rest ratios and Tabata-style cycles.</p>
            )}
          </section>

          <section>
            <h4 className="text-sm font-semibold text-zinc-300 mb-3 uppercase tracking-wider">Time Domain</h4>
            <div className="flex flex-wrap gap-2">
              {TIME_OPTIONS.map(opt => (
                <FilterChip 
                  key={opt} 
                  label={opt} 
                  isSelected={filters.time === opt} 
                  onClick={() => setFilters(prev => ({ ...prev, time: opt }))} 
                />
              ))}
            </div>
          </section>

          <section>
            <h4 className="text-sm font-semibold text-zinc-300 mb-3 uppercase tracking-wider flex items-center gap-2">
              <Target size={14} className="text-primary" /> Body Part Emphasis
            </h4>
            <div className="flex flex-wrap gap-2">
              {BODY_PART_OPTIONS.map(opt => (
                <FilterChip 
                  key={opt} 
                  label={opt} 
                  isSelected={filters.bodyParts.includes(opt)} 
                  onClick={() => toggleBodyPart(opt)} 
                />
              ))}
            </div>
          </section>

          <section>
            <h4 className="text-sm font-semibold text-zinc-300 mb-3 uppercase tracking-wider">Environment / Running</h4>
            <div className="flex flex-wrap gap-2">
              {RUNNING_OPTIONS.map(opt => (
                <FilterChip 
                  key={opt} 
                  label={opt} 
                  isSelected={filters.runningSpace === opt} 
                  onClick={() => setFilters(prev => ({ ...prev, runningSpace: opt }))} 
                />
              ))}
            </div>
          </section>

          <section>
            <h4 className="text-sm font-semibold text-zinc-300 mb-3 uppercase tracking-wider">Difficulty</h4>
            <div className="flex flex-wrap gap-2">
              {DIFFICULTY_OPTIONS.map(opt => (
                <FilterChip 
                  key={opt} 
                  label={opt} 
                  isSelected={filters.difficulty === opt} 
                  onClick={() => setFilters(prev => ({ ...prev, difficulty: opt }))} 
                />
              ))}
            </div>
          </section>

          <section className="space-y-4">
            <div>
              <h4 className="text-sm font-semibold text-zinc-300 mb-3 uppercase tracking-wider">Equipment Available</h4>
              <div className="flex flex-wrap gap-2">
                {EQUIPMENT_OPTIONS.map(opt => (
                  <FilterChip 
                    key={opt} 
                    label={opt} 
                    isSelected={filters.equipment.includes(opt)} 
                    onClick={() => toggleEquipment(opt)} 
                  />
                ))}
              </div>
            </div>

            {/* Conditional Inputs for Equipment Details */}
            {(filters.equipment.includes('Dumbbells') || filters.equipment.includes('Kettlebell') || filters.equipment.includes('Barbell')) && (
              <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800 space-y-5 animate-in fade-in slide-in-from-top-2">
                <h5 className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Select Available Weights</h5>
                
                {filters.equipment.includes('Dumbbells') && (
                  <div>
                    <label className="block text-sm text-zinc-300 mb-2">Dumbbells</label>
                    <div className="flex gap-2">
                      {WEIGHT_OPTIONS.map((opt) => (
                        <button
                          key={opt}
                          onClick={() => updateWeight('dumbbells', opt)}
                          className={`flex-1 py-2 text-sm rounded-lg border transition-colors ${
                            filters.equipmentWeights.dumbbells === opt
                              ? 'bg-primary/20 border-primary text-primary font-semibold'
                              : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-600'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {filters.equipment.includes('Kettlebell') && (
                  <div>
                    <label className="block text-sm text-zinc-300 mb-2">Kettlebells</label>
                    <div className="flex gap-2">
                      {WEIGHT_OPTIONS.map((opt) => (
                        <button
                          key={opt}
                          onClick={() => updateWeight('kettlebell', opt)}
                          className={`flex-1 py-2 text-sm rounded-lg border transition-colors ${
                            filters.equipmentWeights.kettlebell === opt
                              ? 'bg-primary/20 border-primary text-primary font-semibold'
                              : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-600'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {filters.equipment.includes('Barbell') && (
                  <div>
                    <label className="block text-sm text-zinc-300 mb-2">Barbell Loading</label>
                    <div className="flex gap-2">
                      {WEIGHT_OPTIONS.map((opt) => (
                        <button
                          key={opt}
                          onClick={() => updateWeight('barbell', opt)}
                          className={`flex-1 py-2 text-sm rounded-lg border transition-colors ${
                            filters.equipmentWeights.barbell === opt
                              ? 'bg-primary/20 border-primary text-primary font-semibold'
                              : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-600'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </section>

          <section>
            <h4 className="text-sm font-semibold text-zinc-300 mb-3 uppercase tracking-wider">Focus</h4>
            <div className="flex flex-wrap gap-2">
              {FOCUS_OPTIONS.map(opt => (
                <FilterChip 
                  key={opt} 
                  label={opt} 
                  isSelected={filters.focus.includes(opt)} 
                  onClick={() => toggleFocus(opt)} 
                />
              ))}
            </div>
          </section>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-900/50">
          <Button onClick={onApply} className="w-full" size="lg">
            Let's Get Sweaty! 💦
          </Button>
        </div>
      </div>
    </div>
  );
};