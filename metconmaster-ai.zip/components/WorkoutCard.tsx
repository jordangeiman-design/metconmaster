import React from 'react';
import { Workout } from '../types';
import { Clock, Dumbbell, Star, Trophy, Bookmark, BookmarkCheck, Play, Users } from 'lucide-react';
import { StarRating } from './StarRating';

interface WorkoutCardProps {
  workout: Workout;
  onSave?: (id: string) => void;
  isSaved?: boolean;
  onStart?: (workout: Workout) => void;
}

export const WorkoutCard: React.FC<WorkoutCardProps> = ({ workout, onSave, isSaved, onStart }) => {
  // Split description by newlines to render as distinct blocks
  const descriptionLines = workout.description.split('\n').filter(line => line.trim().length > 0);

  return (
    <div className="bg-card border border-zinc-800 rounded-xl p-5 shadow-lg hover:border-zinc-700 transition-colors relative group flex flex-col h-full">
      {/* Benchmark Badge */}
      {workout.isBenchmark && (
        <div className="absolute top-0 right-0 mt-4 mr-4 bg-yellow-500/10 text-yellow-500 text-xs px-2 py-1 rounded-full flex items-center gap-1 border border-yellow-500/20">
          <Trophy size={12} />
          <span>Benchmark</span>
        </div>
      )}

      <div className="flex justify-between items-start mb-3 pr-20">
        <div>
          <h3 className="text-xl font-bold text-white mb-1">{workout.name}</h3>
          <p className="text-sm text-primary font-medium">{workout.type}</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4 text-xs text-zinc-400">
        <div className="flex items-center gap-1 bg-zinc-800/50 px-2 py-1 rounded">
          <Clock size={12} />
          {workout.timeEstimate}
        </div>
        <div className="flex items-center gap-1 bg-zinc-800/50 px-2 py-1 rounded">
          <Dumbbell size={12} />
          {workout.difficulty}
        </div>
        <div className="flex items-center gap-1 bg-zinc-800/50 px-2 py-1 rounded">
          <Star size={12} />
          {workout.focus}
        </div>
      </div>

      <div className="bg-zinc-950/50 rounded-lg p-4 mb-4 font-mono text-sm text-zinc-300 border border-zinc-800/50 flex-grow">
        {descriptionLines.map((line, index) => (
          <div key={index} className="mb-2 last:mb-0 leading-relaxed">
            {line}
          </div>
        ))}
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <div>
             <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Equipment</span>
             <p className="text-xs text-zinc-400 mt-1">{workout.equipmentNeeded.join(', ')}</p>
          </div>
          <div>
             <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Coach's Notes</span>
             <p className="text-xs text-zinc-400 mt-1 italic border-l-2 border-zinc-700 pl-2">{workout.tips}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 border-t border-zinc-800/50 pt-3 mt-1">
           {/* Community Rating */}
           <div className="flex flex-col">
              <span className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider mb-1">Community Rating</span>
              <div className="flex items-center gap-1.5">
                 <Star size={14} className="text-yellow-500 fill-current" />
                 <span className="text-sm font-bold text-white">{workout.averageRating || "New"}</span>
                 <span className="text-xs text-zinc-500">
                   ({(workout.reviewCount || 0) > 1000 ? `${((workout.reviewCount || 0)/1000).toFixed(1)}k` : workout.reviewCount || 0})
                 </span>
              </div>
           </div>

           {/* User Rating */}
           <div className="flex flex-col">
              <span className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider mb-1">Your Rating</span>
              {workout.userRating ? (
                <div className="flex items-center gap-1">
                   <StarRating rating={workout.userRating} onRate={() => {}} interactive={false} size={14} />
                </div>
              ) : (
                <span className="text-xs text-zinc-600 italic">Not rated yet</span>
              )}
           </div>
        </div>

        <div className="pt-2 border-t border-zinc-800 flex gap-3">
          {onStart && (
            <button 
              onClick={() => onStart(workout)}
              className="flex-1 flex items-center justify-center gap-2 bg-primary/10 hover:bg-primary/20 text-primary font-semibold py-2 rounded-lg transition-colors"
            >
              <Play size={16} fill="currentColor" /> Start Workout
            </button>
          )}
        </div>
      </div>

      {onSave && (
        <div className="absolute top-4 right-14 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
          <button 
            onClick={() => onSave(workout.id)}
            className={`p-2 rounded-full transition-colors ${isSaved ? 'text-primary bg-primary/10' : 'text-zinc-500 hover:text-white hover:bg-zinc-800'}`}
            title={isSaved ? "Remove from saved" : "Save workout"}
          >
            {isSaved ? <BookmarkCheck size={20} /> : <Bookmark size={20} />}
          </button>
        </div>
      )}
      {/* Mobile visible save button if not in group hover context */}
      {onSave && (
         <button 
         onClick={() => onSave(workout.id)}
         className={`sm:hidden absolute top-4 right-12 p-2 rounded-full transition-colors ${isSaved ? 'text-primary bg-primary/10' : 'text-zinc-500'}`}
       >
         {isSaved ? <BookmarkCheck size={20} /> : <Bookmark size={20} />}
       </button>
      )}
    </div>
  );
};