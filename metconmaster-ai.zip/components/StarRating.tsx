import React, { useState } from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  onRate: (rating: number) => void;
  interactive?: boolean;
  size?: number;
}

export const StarRating: React.FC<StarRatingProps> = ({ 
  rating, 
  onRate, 
  interactive = true,
  size = 24 
}) => {
  const [hoverRating, setHoverRating] = useState<number | null>(null);

  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={!interactive}
          onClick={() => onRate(star)}
          onMouseEnter={() => interactive && setHoverRating(star)}
          onMouseLeave={() => interactive && setHoverRating(null)}
          className={`transition-colors ${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'}`}
        >
          <Star 
            size={size} 
            fill={(hoverRating !== null ? star <= hoverRating : star <= rating) ? "currentColor" : "none"}
            className={`
              ${(hoverRating !== null ? star <= hoverRating : star <= rating) 
                ? 'text-yellow-500' 
                : 'text-zinc-600'}
            `}
          />
        </button>
      ))}
    </div>
  );
};