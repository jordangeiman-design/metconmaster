import { GoogleGenAI, Type } from "@google/genai";
import { FilterState, Workout } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const WEIGHT_MAP: Record<string, string> = {
  'Light': 'Light/Scaled weights (e.g. DBs < 35lbs, KB < 1.5pd, Barbell < 95lbs)',
  'Medium': 'Medium/Rx weights (e.g. DBs 35-50lbs, KB 1.5pd, Barbell 95-135lbs)',
  'Heavy': 'Heavy weights (e.g. DBs 50lbs+, KB 2pd+, Barbell 135lbs+)'
};

export const generateWorkouts = async (filters: FilterState, excludeNames: string[] = []): Promise<Workout[]> => {
  const modelId = "gemini-3-pro-preview"; 

  // Construct detailed equipment string
  let equipmentDetails = filters.equipment.join(', ') || "Any";
  
  if (filters.equipment.includes('Dumbbells') && filters.equipmentWeights.dumbbells) {
    const w = filters.equipmentWeights.dumbbells;
    equipmentDetails += ` (Dumbbells: ${WEIGHT_MAP[w] || w})`;
  }
  if (filters.equipment.includes('Kettlebell') && filters.equipmentWeights.kettlebell) {
    const w = filters.equipmentWeights.kettlebell;
    equipmentDetails += ` (Kettlebells: ${WEIGHT_MAP[w] || w})`;
  }
  if (filters.equipment.includes('Barbell') && filters.equipmentWeights.barbell) {
    const w = filters.equipmentWeights.barbell;
    equipmentDetails += ` (Barbell: ${WEIGHT_MAP[w] || w})`;
  }

  // Structure Details
  let structureInstruction = "";
  if (filters.structure !== 'Any') {
    if (filters.structure === 'EMOM (Varied)') {
      structureInstruction = "7. **Structure**: EMOM/Interval based. Do NOT just do 1-minute intervals. Include E2MOM, E3MOM, or alternating minute structures (e.g., Min 1: A, Min 2: B).";
    } else if (filters.structure === 'Intervals / Work-Rest') {
      structureInstruction = "7. **Structure**: High Intensity Intervals with specific rest periods. Examples: 4 rounds of 4 min work/2 min rest, Tabata style (20s/10s), or 1:1 work-to-rest ratios.";
    } else {
      structureInstruction = `7. **Structure**: Focus strictly on ${filters.structure} format.`;
    }
  }

  // Add rating instruction
  let ratingInstruction = "";
  if (filters.minRating > 0) {
    ratingInstruction = `6. **Minimum Rating**: The user only wants to see top-rated/community favorite workouts. Prioritize highly famous and effective workouts.`;
  }

  // Exclusion instruction
  let exclusionInstruction = "";
  if (excludeNames.length > 0) {
    const recentExclusions = excludeNames.slice(-50).join(', ');
    exclusionInstruction = `**IMPORTANT**: Do NOT include the following workouts, as the user has already seen them: ${recentExclusions}. Provide FRESH, unique alternatives.`;
  }

  const prompt = `
    You are an expert Functional Fitness and CrossFit coach with comprehensive knowledge of every "Metcon" (Metabolic Conditioning) workout ever published, including:
    - All "Girl" WODs (e.g., Fran, Cindy, Diane)
    - All Hero WODs (e.g., Murph, DT, Bull)
    - Every CrossFit Open, Regionals, and Games workout from 2011 to present
    - Popular gym benchmarks and competition classics

    Find or design **25 distinct** Metabolic Conditioning workouts based strictly on the following user criteria:
    
    1. **Equipment Available**: ${equipmentDetails}
    2. **Running Space Available**: ${filters.runningSpace}
    3. **Time Domain**: ${filters.time}
    4. **Difficulty Level**: ${filters.difficulty}
    5. **Training Focus**: ${filters.focus.join(', ') || "GPP"}
    6. **Body Part Emphasis**: ${filters.bodyParts.join(', ') || "Balanced/Full Body"}
    ${structureInstruction}
    ${ratingInstruction}
    ${exclusionInstruction}

    **RULES**:
    - PRIORITIZE real, named benchmark workouts if they match the filters. 
    - If a benchmark needs slight scaling to fit the time domain or equipment, mention it in the tips.
    - If structure is EMOM (Varied), ensure complex interval formats like E2MOM (Every 2 Minutes), E3MOM, or EMOM with rest minutes built in.
    - If structure is Intervals/Work-Rest, ensure distinct rest periods are detailed in the description (e.g., "Rest 2 minutes between rounds").
    - Ensure a mix of structures if 'Any' is selected, but be strict if a specific structure is requested.
    - The 'description' field MUST use newlines for each movement or round.
    
    For each workout, estimate community stats:
    - 'averageRating': (e.g., 4.8)
    - 'reviewCount': High for benchmarks (10,000+), lower for custom/niche (50-500).
    
    **CRITICAL FORMATTING**:
    Example:
    "21-15-9 reps for time of:
    Thrusters (95/65 lb)
    Pull-ups"
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            workouts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  type: { type: Type.STRING },
                  description: { type: Type.STRING },
                  timeEstimate: { type: Type.STRING },
                  equipmentNeeded: { type: Type.ARRAY, items: { type: Type.STRING } },
                  difficulty: { type: Type.STRING },
                  focus: { type: Type.STRING },
                  tips: { type: Type.STRING },
                  isBenchmark: { type: Type.BOOLEAN },
                  averageRating: { type: Type.NUMBER },
                  reviewCount: { type: Type.INTEGER }
                },
                required: ["name", "type", "description", "timeEstimate", "equipmentNeeded", "difficulty", "focus", "tips", "isBenchmark", "averageRating", "reviewCount"]
              }
            }
          }
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) throw new Error("No data from AI");

    const parsed = JSON.parse(jsonText);
    return parsed.workouts.map((w: any) => ({ ...w, id: crypto.randomUUID() }));

  } catch (error) {
    console.error("Error generating workouts:", error);
    throw error;
  }
};