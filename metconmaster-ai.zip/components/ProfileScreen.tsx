import React, { useState } from 'react';
import { UserProfile, Workout, CompletedWorkout } from '../types';
import { authService } from '../services/mockDatabase';
import { Button } from './Button';
import { WorkoutCard } from './WorkoutCard';
import { User, Mail, Phone, ArrowLeft, Bookmark, Star, History, Calendar, Play } from 'lucide-react';

interface ProfileScreenProps {
  user: UserProfile;
  savedWorkouts: Workout[];
  workoutHistory: CompletedWorkout[];
  onUpdateUser: (user: UserProfile) => void;
  onLogout: () => void;
  onBack: () => void;
  onToggleSave: (id: string) => void;
  onStartWorkout: (w: Workout) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  savedWorkouts,
  workoutHistory,
  onUpdateUser,
  onLogout,
  onBack,
  onToggleSave,
  onStartWorkout
}) => {
  const [activeTab, setActiveTab] = useState<'SAVED' | 'HISTORY'>('SAVED');
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone
  });
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const updated = await authService.updateProfile(formData);
      onUpdateUser(updated);
      setIsEditing(false);
    } catch (e) {
      console.error("Failed to update");
    } finally {
      setLoading(false);
    }
  };

  const ratedWorkoutsCount = workoutHistory.filter(h => h.rating).length;
  const avgUserRating = ratedWorkoutsCount > 0 
    ? (workoutHistory.reduce((acc, h) => acc + (h.rating || 0), 0) / ratedWorkoutsCount).toFixed(1)
    : '0';

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-dark pb-20">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-dark/90 backdrop-blur-md border-b border-zinc-800">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white">
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-xl font-bold text-white">My Profile</h1>
          </div>
          <button 
            onClick={onLogout}
            className="text-red-400 text-sm font-medium hover:text-red-300"
          >
            Sign Out
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6 space-y-8">
        
        {/* User Info Card */}
        <div className="bg-card border border-zinc-800 rounded-2xl p-6">
          <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center mb-6">
            <div className="w-20 h-20 rounded-full bg-zinc-800 border-2 border-zinc-700 overflow-hidden shrink-0">
               {user.avatarUrl ? (
                 <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
               ) : (
                 <div className="w-full h-full flex items-center justify-center">
                    <User className="text-zinc-500" size={32} />
                 </div>
               )}
            </div>
            
            <div className="flex-1 w-full">
              {isEditing ? (
                 <div className="space-y-3">
                    <div className="relative">
                       <User className="absolute left-3 top-3 text-zinc-500" size={16} />
                       <input 
                          value={formData.name}
                          onChange={e => setFormData({...formData, name: e.target.value})}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded-lg py-2 pl-9 text-sm text-white focus:border-primary outline-none"
                          placeholder="Full Name"
                       />
                    </div>
                 </div>
              ) : (
                 <div>
                    <h2 className="text-2xl font-bold text-white">{user.name || 'Guest User'}</h2>
                    <div className="flex flex-col gap-1 text-zinc-400 text-sm mt-1">
                       {user.email && <span className="flex items-center gap-2"><Mail size={14}/> {user.email}</span>}
                       {user.phone && <span className="flex items-center gap-2"><Phone size={14}/> {user.phone}</span>}
                    </div>
                 </div>
              )}
            </div>
            
            <div>
              {isEditing ? (
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" onClick={() => setIsEditing(false)}>Cancel</Button>
                  <Button size="sm" onClick={handleSave} isLoading={loading}>Save</Button>
                </div>
              ) : (
                <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>Edit Name</Button>
              )}
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-4 border-t border-zinc-800 pt-6">
             <div className="text-center">
                <p className="text-2xl font-bold text-white">{user.workoutsCompleted}</p>
                <p className="text-xs uppercase tracking-wider text-zinc-500 mt-1">Completed</p>
             </div>
             <div className="text-center border-l border-zinc-800">
                <p className="text-2xl font-bold text-white">{savedWorkouts.length}</p>
                <p className="text-xs uppercase tracking-wider text-zinc-500 mt-1">Saved</p>
             </div>
             <div className="text-center border-l border-zinc-800">
                <div className="flex items-center justify-center gap-1">
                   <p className="text-2xl font-bold text-white">{avgUserRating}</p>
                   <Star size={16} className="text-yellow-500 fill-current" />
                </div>
                <p className="text-xs uppercase tracking-wider text-zinc-500 mt-1">Avg Rating</p>
             </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-zinc-800">
           <button 
            onClick={() => setActiveTab('SAVED')}
            className={`flex-1 py-4 text-sm font-semibold border-b-2 transition-all flex items-center justify-center gap-2 ${activeTab === 'SAVED' ? 'border-primary text-primary bg-primary/5' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}
           >
              <Bookmark size={18} /> Saved ({savedWorkouts.length})
           </button>
           <button 
            onClick={() => setActiveTab('HISTORY')}
            className={`flex-1 py-4 text-sm font-semibold border-b-2 transition-all flex items-center justify-center gap-2 ${activeTab === 'HISTORY' ? 'border-primary text-primary bg-primary/5' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}
           >
              <History size={18} /> History ({workoutHistory.length})
           </button>
        </div>

        {/* List Content */}
        <div>
           {activeTab === 'SAVED' ? (
              savedWorkouts.length === 0 ? (
                <div className="text-center py-12 border border-dashed border-zinc-800 rounded-xl">
                   <Bookmark className="mx-auto text-zinc-600 mb-4" size={32} />
                   <p className="text-zinc-500">You haven't saved any workouts yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-6">
                  {savedWorkouts.map(workout => (
                    <WorkoutCard 
                      key={workout.id} 
                      workout={workout} 
                      onSave={onToggleSave}
                      isSaved={true}
                      onStart={onStartWorkout}
                    />
                  ))}
                </div>
              )
           ) : (
              workoutHistory.length === 0 ? (
                <div className="text-center py-12 border border-dashed border-zinc-800 rounded-xl">
                   <History className="mx-auto text-zinc-600 mb-4" size={32} />
                   <p className="text-zinc-500">No workout history found yet.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {workoutHistory.map((historyItem) => (
                    <div key={historyItem.historyId} className="bg-card border border-zinc-800 rounded-xl p-5 group hover:border-zinc-700 transition-colors">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-bold text-white text-lg">{historyItem.workout.name}</h4>
                            {historyItem.rating && (
                              <div className="flex items-center gap-0.5 bg-yellow-500/10 px-1.5 py-0.5 rounded text-xs text-yellow-500 font-bold border border-yellow-500/20">
                                <Star size={10} fill="currentColor" />
                                {historyItem.rating}
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-3 text-xs text-zinc-500">
                             <span className="flex items-center gap-1"><Calendar size={12} /> {formatDate(historyItem.completedAt)}</span>
                             <span className="text-zinc-700">•</span>
                             <span className="text-primary font-medium">{historyItem.workout.type}</span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                           <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-xs"
                            onClick={() => {
                              // Deep copy to ensure unique UI ID if needed
                              onStartWorkout({...historyItem.workout, id: historyItem.workout.id});
                            }}
                           >
                              <Play size={14} className="mr-1" /> Re-run
                           </Button>
                           <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-xs"
                            onClick={() => {
                              // We use the WorkoutCard view style logic by temporarily "viewing" it 
                              // Actually, just starting it is the common pattern for re-viewing.
                              onStartWorkout(historyItem.workout);
                            }}
                           >
                              View Details
                           </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )
           )}
        </div>

      </main>
    </div>
  );
};